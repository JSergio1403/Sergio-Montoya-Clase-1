﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_SJMP_1016622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string pass;
            string usuario;
            int q = 0;
           
            Boolean usa;
            do
            {
                Console.WriteLine("Ingrese su usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingrese su contraseña");
                pass = Console.ReadLine();

                usa = Login(usuario, pass);
                if (usa==true)
                {
                    Console.WriteLine("Usuario y contraseña correcto");
                    q = 3;
                }
                else
                {
                    q++;
                    Console.WriteLine("Usuario y contrasela incorrecta, intente de nuevo");
                    Console.WriteLine("Numero de intento realizados" + q);
                }
            } while (q < 3);
            Console.ReadKey();
        }
        static bool Login(string username, string password)
        {
     
            if (username=="usuario1" && password=="asdasd")
            {
                return true;
            }
            else {

                return false;
            }
                

        }
        
    }
}
