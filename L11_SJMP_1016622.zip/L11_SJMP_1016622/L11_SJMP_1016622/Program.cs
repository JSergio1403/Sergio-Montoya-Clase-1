﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_SJMP_1016622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] clase1;
            clase1 = new double[4];

            double[] clase2; ;
            clase2 = new double[4];

            int q=0;
            int k=0;
            int l=0;
            int r=0;
            double aprov1 = 0;
            double aprov2 = 0;
            double reprov1=0;
            double reprov2=0;
            double aprovtot = 0;
            double reprovtot = 0;
            double total1=0;
            double prom1=0;
            double total2 = 0;
            double prom2 = 0;
            double promtotal = 0;
            int a=0;
            int b=0;
            int c=0;    
            int d=0;
            int cont90=0;
            int cont75 = 0;


            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("ingrese la nota de calculo del estudiante " + (i + 1)+" de la sección 1");
                clase1[i] = double.Parse(Console.ReadLine());

            }

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("ingrese la nota de calculo del estudiante " + (i + 1) + " de la sección 2");
                clase2[i] = double.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 4; i++)
            {
                if (clase1[i]>=65)
                {
                    q++;
                }
                else
                {
                    k++;
                }
            }
            aprov1 = Convert.ToDouble(q)/ 4 * 100;
            reprov1 = Convert.ToDouble(k) / 4 * 100;
            Console.WriteLine("El porcentaje de alumnos aprovados de la sección 1 es: " + aprov1+"%");
            Console.WriteLine("El porcentaje de alumnos reprovados de la sección 1 es: "+reprov1+"%");
            Console.WriteLine("");

            for (int i = 0; i < 4; i++)
            {
                if (clase2[i] >= 65)
                {
                    l++;
                }
                else
                {
                    r++;
                }
            }
            aprov2 = Convert.ToDouble(l) / 4 * 100;
            reprov2 = Convert.ToDouble(r) / 4 * 100;
            Console.WriteLine("El porcentaje de alumnos aprovados de la sección 2 es: " + aprov2 + "%");
            Console.WriteLine("El porcentaje de alumnos reprovados de la sección 2 es: " + reprov2 + "%");
            Console.WriteLine("");

            aprovtot=((Convert.ToDouble(q)+Convert.ToDouble(l))/8)*100;
            Console.WriteLine("El porcentaje total de alumnos aprovados entre ambas secciones es: "+aprovtot+"%");
            Console.WriteLine("");
            
            reprovtot= ((Convert.ToDouble(k) + Convert.ToDouble(r)) / 8) * 100;
            Console.WriteLine("El porcentaje total de alumnos reprovados entre ambas secciones es: " + reprovtot + "%");
            Console.WriteLine("");

            for (int i = 0; i < 4; i++)
            {
                total1= total1 + clase1[i];
            }
            prom1 = total1 / 4;
            Console.WriteLine("El promedio de notas de la sección 1 es: " + prom1);
            Console.WriteLine("");

            for (int i = 0; i < 4; i++)
            {
                total2 = total2 + clase2[i];
            }
            prom2 = total2 / 4;
            Console.WriteLine("El promedio de notas de la sección 2 es: " + prom2);
            Console.WriteLine("");

            promtotal = (total1 + total2) / 8;
            Console.WriteLine("El promedio total de notas de ambas secciones es: "+promtotal);
            Console.WriteLine("");

            for (int i = 0; i < 4; i++)
            {
                if (clase1[i]>90)
                {
                    a++;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                if (clase2[i] > 90)
                {
                    b++;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                if (clase1[i] < 75)
                {
                    c++;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                if (clase1[i] < 75)
                {
                    d++;
                }
            }
            cont90 = a + b;
            cont75=c+ d;

            Console.WriteLine("La cantidad de estudiantes con un promedio mayor a 90 es: " + cont90);
            Console.WriteLine("La cantidad de estudiantes con un promedio menor a 75 es: " + cont75);
            Console.ReadKey();
        }
    }
}
