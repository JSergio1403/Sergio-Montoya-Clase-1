﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_SJMP_1016622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] datos1 = new double[4, 5];
            double[,] datos2 = new double[4, 5];
            double[,] resultado= new double[4, 5];
            double suma1 = 0;
           
            
            
            double promedio1 = 0;
          

            for (int i = 0; i < 4; i++)
            {
                for (int q = 0; q < 5; q++)
                {
                    Console.WriteLine("Ingrese un valor para la primer matriz");
                    datos1[i,q]=double.Parse(Console.ReadLine());
                }
            }
            for (int i = 0; i < 4 ; i++)
            {
                for (int q = 0; q < 5; q++)
                {
                    suma1 = suma1 + datos1[i, q];
                }
            }
            Console.WriteLine("El resultado de los valores de la matriz 1 es: " + suma1);
            promedio1 = suma1 / 20;
            Console.WriteLine("");
            Console.WriteLine("El promedio de la matriz 1 es: " + promedio1);
            Console.WriteLine("");

            for (int i = 0; i < 4; i++)
            {
                for (int q = 0; q < 5; q++)
                {
                    Console.WriteLine("Ingrese un valor para la segunda matriz");
                    datos2[i, q] = double.Parse(Console.ReadLine());
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int q = 0; q < 5; q++)
                {
                    resultado[i, q] = datos1[i, q] + datos2[i, q];
                }
            }
            for (int i = 0; i <4 ; i++)
            {
                for (int q = 0; q < 5; q++)
                {
                    Console.Write(resultado[i, q]+" ");
                }
                Console.WriteLine("");
            }
            Console.ReadKey();
            

            
            

        }
    }
}
